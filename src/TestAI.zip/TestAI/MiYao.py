from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate

# 设置 OpenAI API 密钥
import openai
openai.api_key = "你的OpenAI API密钥"

# 初始化 OpenAI LLM
llm = OpenAI(model="gpt-3.5-turbo", temperature=0.7)
