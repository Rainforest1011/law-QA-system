#在 urls.py 中注册这个视图
from django.urls import path
from . import views

urlpatterns = [
    path('ask/', views.ask),
]
