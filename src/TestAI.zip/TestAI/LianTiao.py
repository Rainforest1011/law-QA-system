#创建 LangChain 工具和链条
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate

# 创建一个提示模板
template = "你是一个非常聪明的助手，帮我回答以下问题: {question}"
prompt = PromptTemplate(input_variables=["question"], template=template)

# 创建链条
chain = LLMChain(llm=llm, prompt=prompt)

# 生成答案
def get_answer(question: str):
    return chain.run(question)
