from django.http import JsonResponse
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# 初始化 OpenAI LLM
llm = OpenAI(model="gpt-3.5-turbo", temperature=0.7)
template = "你是一个非常聪明的助手，帮我回答以下问题: {question}"
prompt = PromptTemplate(input_variables=["question"], template=template)
chain = LLMChain(llm=llm, prompt=prompt)

def get_answer(question):
    return chain.run(question)

def ask(request):
    question = request.GET.get('question')
    if question:
        answer = get_answer(question)
        return JsonResponse({"answer": answer})
    else:
        return JsonResponse({"error": "No question provided"}, status=400)
